## **Dados**

### **Regressão**

- `insurance_SLR`: custos de saúde (regressão linear simples)
-  `insurance`: custos de saúde (regressão linear múltipla)
- `Florida_listings`: dados de imóveis para venda extraídos do Zillow (preenchimento de nulos)

### **Sistema de detecção de fraudes**

- `transactions`: transações em uma fintech
- `validated_transactions`: transações fraudulentas validadas por equipe de análise de fraude